"""
ROADGUARD AI - Utilities Package
"""
